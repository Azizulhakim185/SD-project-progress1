<?php
require_once 'Function.php';
require_once 'send_code.php';

//for managing signup
if(isset($_GET['signup'])) {
 $response=validateSignupForm($_POST);
if ($response['status']){
   //echo isEmailRegistered('azizulhakimshouvo@gmail.com');
/* $email = 'azizulhakimshuvo185@gmail.com'; // The email to be checked
if (isEmailRegistered($email)) {
    echo "Email is registered.";
} else {
    echo "Email is not registered.";

*/
    if(createUser($_POST)){
        header('location:../../?login');
    }
    else{
        echo "<script>alert('something is worng')</script>";
    }

}
else{
    $_SESSION['error']=$response;
    $_SESSION['formdata']=$_POST;
     header("location:../../?signup");
}
}


//for managing login
if(isset($_GET['login'])) {
   $response=validateLoginForm($_POST);
   if ($response['status']){
      //echo isEmailRegistered('azizulhakimshouvo@gmail.com');
   /* $email = 'azizulhakimshuvo185@gmail.com'; // The email to be checked
   if (isEmailRegistered($email)) {
       echo "Email is registered.";
   } else {
       echo "Email is not registered.";
   
   */
       $_SESSION['Auth']=true;
       $_SESSION['userdata']=$response['user'];


       if($response['user']['ac_status']==0){
        $_SESSION['code']= $code = rand(111111,999999);
        sendCode($response['user']['email'],'Verify  Your Email',$code);

       }
       header("location:../../");
   
   }
   else{
       $_SESSION['error']=$response;
       $_SESSION['formdata']=$_POST;
        header("location:../../?login");
   }
   }
   
   //if(isset($_GET['resend_code'])){

       // $_SESSION['code']= $code = rand(111111,999999);
       // sendCode($_SESSION['userdata']['email'],'Verify  Your Email',$code);
       // header('location:../../?resended')
       
   //}
   if(isset($_GET['verify_email'])){

    $user_code = $_POST['code'];
    $code = $_SESSION['code'];
    if($code==$user_code){
       verifyEmail($_SESSION['userdata']['email']);
    }else{
        $response['msg']='incorrect verification code !';
        if($_POST['code']){
            $response['msg']='enter 6 digit code';
        }
        $response['field']='email_verify';
        $_SESSION['error']=$response;
        header('location:../../');

    }
}

