
<?php
require_once'assets/php/Function.php';
if(isset($_SESSION['Auth'])){
    $user = getUser($_SESSION['userdata']['id']);
}

if(isset($_SESSION['Auth']) && $user['ac_status']==1){
    showPage('header' , ['page_tittle'=>'Home']);
    showPage('wall');
}
elseif(isset($_SESSION['Auth']) && $user['ac_status']==0){
    showPage('header' , ['page_tittle'=>'Verify Your Email']);
    showPage('verify_email');
}
elseif(isset($_SESSION['Auth']) && $user['ac_status']==2){
    showPage('header' , ['page_tittle'=>'Blocked']);
    showPage('blocked');
}
elseif(isset($_GET['signup'])){

    showPage('header' , ['page_tittle'=>'Social Plus - SignUp']);
    showPage('signup');
   
}
elseif(isset($_GET['login'])){
    showPage('header' , ['page_tittle'=>'Social Plus - Login']);
    showPage('login');
}else{
    showPage('header' , ['page_tittle'=>'Social Plus - Login']);
    showPage('login');
}
showPage('Footer'); 
unset($_SESSION['error']);
unset($_SESSION['formdata']);


